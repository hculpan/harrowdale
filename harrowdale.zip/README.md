# shadowdale-campaign

A static site with info on my Shadowdale 2nd Edition AD&amp;D campaign

# Run locally

bundle exec jekyll serve

# Clean

bundle exec jekyll clean

# Build

bundle exec jekyll build
